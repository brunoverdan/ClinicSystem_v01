<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Cadastrar Ficha de Cliente</h1>

    <form action="<?php echo e(route('fichas.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="queixa">Queixa</label>
            <textarea name="queixa" class="form-control" rows="3"></textarea>
        </div>

        <div class="form-group">
            <label for="habito">Hábito</label>
            <textarea name="habito" class="form-control" rows="3"></textarea>
        </div>

        <div class="form-group">
            <label for="anamnesia">Anamnese</label>
            <textarea name="anamnesia" class="form-control" rows="3"></textarea>
        </div>

        <div class="form-group">
            <label for="data">Data</label>
            <input type="date" name="data" class="form-control">
        </div>

        <div class="form-group">
            <label for="cliente_id">ID do Cliente</label>
            <input type="number" name="cliente_id" class="form-control">
        </div>

        <hr>
        <h2>Perguntas</h2>

        <?php $__currentLoopData = $perguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pergunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                <label><?php echo e($pergunta->pergunta); ?></label>

                <?php if($pergunta->modelo == 'modelo_01'): ?>
                    <div>
                        <label>Resposta:</label><br>
                        <input type="radio" name="perguntas[<?php echo e($pergunta->id); ?>][resposta]" value="sim"> Sim
                        <input type="radio" name="perguntas[<?php echo e($pergunta->id); ?>][resposta]" value="nao"> Não
                    </div>
                    <div>
                        <label>Quais?</label>
                        <input type="text" name="perguntas[<?php echo e($pergunta->id); ?>][quais]" class="form-control">
                    </div>

                <?php elseif($pergunta->modelo == 'modelo_02'): ?>
                    <div>
                        <input type="checkbox" name="perguntas[<?php echo e($pergunta->id); ?>][mais]" value="1"> Mais
                        <input type="checkbox" name="perguntas[<?php echo e($pergunta->id); ?>][menos]" value="1"> Menos
                        <input type="checkbox" name="perguntas[<?php echo e($pergunta->id); ?>][direito]" value="1"> Direito
                        <input type="checkbox" name="perguntas[<?php echo e($pergunta->id); ?>][esquerdo]" value="1"> Esquerdo
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit" class="btn btn-primary">Salvar Ficha</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log("Hi, I'm using the Laravel-AdminLTE package!"); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bruno\temp\CS\ClinicSystem_v01\resources\views/Cadastro/Ficha/create.blade.php ENDPATH**/ ?>