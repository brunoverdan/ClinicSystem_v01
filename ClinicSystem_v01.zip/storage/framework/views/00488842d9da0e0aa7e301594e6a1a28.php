<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Fichas de Clientes</h1>

    <!-- Botão para cadastrar nova ficha -->
    <div class="mb-3">
        <a href="<?php echo e(route('fichas.create')); ?>" class="btn btn-primary">Cadastrar Nova Ficha</a>
    </div>

   
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log("Hi, I'm using the Laravel-AdminLTE package!"); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bruno\temp\CS\ClinicSystem_v01\resources\views/Cadastro/Ficha/index.blade.php ENDPATH**/ ?>