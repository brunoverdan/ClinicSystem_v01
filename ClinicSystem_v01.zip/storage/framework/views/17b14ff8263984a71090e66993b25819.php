<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Criar Pergunta</h1>

    <form action="<?php echo e(route('pergunta_mod_02.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Pergunta</label>
            <input type="text" name="pergunta" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Mais</label>
            <input type="number" name="mais" class="form-control">
        </div>

        <div class="form-group">
            <label>Menos</label>
            <input type="number" name="menos" class="form-control">
        </div>

        <div class="form-group">
            <label>Direito</label>
            <input type="number" name="direito" class="form-control">
        </div>

        <div class="form-group">
            <label>Esquerdo</label>
            <input type="number" name="esquerdo" class="form-control">
        </div>

        <div class="form-group">
            <label>Ativo</label>
            <input type="number" name="ativo" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-success">Salvar</button>
        <a href="<?php echo e(route('pergunta_mod_02.index')); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log("Hi, I'm using the Laravel-AdminLTE package!"); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bruno\temp\CS\ClinicSystem_v01\resources\views/Cadastro/Pergunta_mod_02/create.blade.php ENDPATH**/ ?>