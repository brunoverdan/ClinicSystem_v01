<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Criar Pergunta</h1>

    <form action="<?php echo e(route('pergunta_mod_01.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>Pergunta:</label>
        <input type="text" name="pergunta" required>
        <label>Ativo:</label>
        <input type="number" name="ativo" required>
        <button type="submit">Salvar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log("Hi, I'm using the Laravel-AdminLTE package!"); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bruno\temp\CS\ClinicSystem_v01\resources\views/Cadastro/Pergunta_mod_01/create.blade.php ENDPATH**/ ?>