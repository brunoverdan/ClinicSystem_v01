<div class="container">
    <h1>Registrar Nova Evolução</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('evolucoes.store', ['cliente_id' => $cliente->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="data">Data:</label>
            <input type="date" class="form-control" name="data">
        </div>

        <div class="form-group">
            <label for="descricao">Descrição:</label>
            <textarea class="form-control" name="descricao"></textarea>
        </div>
        
        
        <button type="submit" class="btn btn-success">Salvar</button>
    </form>
</div>

<div class="container">
    <h3 class="my-4">Lista de Evoluções</h3>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Data</th>
                <th>Descrição</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $evolucoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evolucao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(\Carbon\Carbon::parse($evolucao->data)->format('d/m/Y')); ?></td>
                <td style="max-width: 100px; word-break: break-word;"><?php echo e($evolucao->descricao); ?></td>
                <td>
                    <a href="<?php echo e(route('evolucoes.edit', $evolucao->id)); ?>" class="btn btn-sm btn-warning">Editar</a>

                    <!-- Botão para abrir o modal de exclusão -->
                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#modal-delete-<?php echo e($evolucao->id); ?>">
                        Excluir
                    </button>

                    <!-- Modal de confirmação para excluir -->
                    <div class="modal fade" id="modal-delete-<?php echo e($evolucao->id); ?>" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-warning">
                                    <h5 class="modal-title" id="modalLabel">Confirmação de Exclusão</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    Tem certeza que deseja excluir essa evolução?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                    <form action="<?php echo e(route('evolucoes.destroy', $evolucao->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Excluir</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\Bruno\temp\CS\ClinicSystem_v01\resources\views/Movimentacao/FichaCliente/form_evolucao.blade.php ENDPATH**/ ?>