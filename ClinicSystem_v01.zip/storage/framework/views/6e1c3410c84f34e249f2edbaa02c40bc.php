<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<form action="<?php echo e(route('files.store', ['cliente_id' => $cliente->id])); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="name">Nome do Arquivo</label>
        <input type="text" name="name" class="form-control" required>
    </div>

    <div class="form-group">
        <label for="file">Escolha o Arquivo</label>
        <input type="file" name="file" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-primary">Salvar Arquivo</button>
</form>

<hr>

<h3 class="my-4">Arquivos Cadastrados</h3>

<?php if($files->isEmpty()): ?>
    <p>Nenhum arquivo cadastrado.</p>
<?php else: ?>
    <div class="list-group">
        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-group-item d-flex justify-content-between align-items-center">
                <span>
                    <i class="bi bi-file-earmark"></i> <!-- Ícone de arquivo -->
                    <?php echo e($file->name); ?>

                </span>
                <a href="<?php echo e(route('files.download', $file->id)); ?>" class="btn btn-sm btn-primary">
                    <i class="bi bi-download"></i> <!-- Ícone de download -->
                    Baixar
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php /**PATH C:\Bruno\temp\CS\ClinicSystem_v01\resources\views/Movimentacao/File/index.blade.php ENDPATH**/ ?>