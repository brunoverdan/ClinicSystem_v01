<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Ficha Cliente</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="tab1-tab" data-bs-toggle="tab" data-bs-target="#tab1"
                            type="button" role="tab" aria-controls="tab1" aria-selected="true">Cliente</button>
                    </li>
                    <?php $__currentLoopData = $perguntas->groupBy('aba'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aba => $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="tab<?php echo e($loop->index + 2); ?>-tab" data-bs-toggle="tab"
                                data-bs-target="#tab<?php echo e($loop->index + 2); ?>" type="button" role="tab"
                                aria-controls="tab<?php echo e($loop->index + 2); ?>" aria-selected="false"><?php echo e(ucfirst($aba)); ?></button>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="tab5-tab" data-bs-toggle="tab" data-bs-target="#tab5" type="button"
                            role="tab" aria-controls="tab5" aria-selected="false">Medidas</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="tab6-tab" data-bs-toggle="tab" data-bs-target="#tab6" type="button"
                            role="tab" aria-controls="tab6" aria-selected="false">Evolução</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="tab7-tab" data-bs-toggle="tab" data-bs-target="#tab7" type="button"
                            role="tab" aria-controls="tab7" aria-selected="false">Arquivo</button>
                    </li>
                    <li class="nav-item ms-auto">
                        <a href="#" class="nav-link text-muted"><i class="fa fa-gear"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="tab1-tab">
                        <div class="container mt-5">
                            <!-- Informações do Cliente -->
                            <div class="row">
                                <!-- Coluna 1 -->
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Informações do Cliente</h5>
                                        </div>
                                        <div class="card-body">
                                            <p><strong>Nome:</strong> <?php echo e($cliente->nome); ?></p>
                                            <p><strong>Endereço:</strong> <?php echo e($cliente->endereco); ?></p>
                                            <p><strong>Telefone:</strong> <?php echo e($cliente->telefone); ?></p>
                                            <p><strong>Observação:</strong> <?php echo e($cliente->observacao); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Coluna 2 -->
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-header">
                                            <h5>Informações Adicionais</h5>
                                        </div>
                                        <div class="card-body">
                                            <p><strong>Email:</strong> <?php echo e($cliente->email); ?></p>
                                            <p><strong>Cidade:</strong> <?php echo e($cliente->cidade); ?></p>
                                            <p><strong>Estado (UF):</strong> <?php echo e($cliente->uf); ?></p>
                                            <p><strong>Sexo:</strong> <?php echo e($cliente->sexo); ?></p>
                                            <p><strong>Data de Nascimento:</strong>
                                                <?php echo e(\Carbon\Carbon::parse($cliente->data_nascimento)->format('d/m/Y')); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php $__currentLoopData = $perguntas->groupBy('aba'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aba => $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade" id="tab<?php echo e($loop->index + 2); ?>" role="tabpanel"
                            aria-labelledby="tab<?php echo e($loop->index + 2); ?>-tab">
                            <?php if(count($respostas) > 0): ?>
                                <?php echo $__env->make('Movimentacao.Ficha.edit', ['perguntas' => $questions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                                <?php echo $__env->make('Movimentacao.Ficha.create', ['perguntas' => $questions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="tab-pane fade" id="tab5" role="tabpanel" aria-labelledby="tab5-tab">
                        <?php echo $__env->make('Movimentacao.Medida.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="tab-pane fade" id="tab6" role="tabpanel" aria-labelledby="tab6-tab">
                        <?php echo $__env->make('Movimentacao.FichaCliente.form_evolucao', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                    <div class="tab-pane fade" id="tab7" role="tabpanel" aria-labelledby="tab7-tab">

                        <?php echo $__env->make('Movimentacao.File.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\CliniMaster\CliniMaster_v01\resources\views/Movimentacao/FichaCliente/ficha_cliente.blade.php ENDPATH**/ ?>