<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Editar Pergunta</h1>

        <form action="<?php echo e(route('modelo_perguntas.update', $modeloPergunta->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <?php if(auth()->user()->nivel == 'administrativo'): ?>
                <div class="form-group">
                    <label for="user_id">Usuário Profissional</label>
                    <select name="user_id" class="form-control" required>
                        <option value="" disabled selected>Selecione um usuário profissional</option>
                        <?php $__currentLoopData = $profissionais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profissional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($profissional->id); ?>"
                                <?php echo e(old('user_id', $modeloPergunta->user_id) == $profissional->id ? 'selected' : ''); ?>>
                                <?php echo e($profissional->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php else: ?>
                <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
            <?php endif; ?>

            <div class="form-group">
                <label for="pergunta">Pergunta</label>
                <input type="text" name="pergunta" class="form-control"
                    value="<?php echo e(old('pergunta', $modeloPergunta->pergunta)); ?>" required>
            </div>

            <div class="form-group">
                <label for="modelo">Modelo</label>
                <select name="modelo" class="form-control" required>
                    <option value="modelo_01" <?php echo e($modeloPergunta->modelo == 'modelo_01' ? 'selected' : ''); ?>>Modelo 01
                    </option>
                    <option value="modelo_02" <?php echo e($modeloPergunta->modelo == 'modelo_02' ? 'selected' : ''); ?>>Modelo 02
                    </option>
                    <option value="modelo_03" <?php echo e($modeloPergunta->modelo == 'modelo_03' ? 'selected' : ''); ?>>Modelo 03
                    </option>
                </select>
            </div>

            

            <input type="hidden" name="aba" value="Lombar">

            <!-- Descrição dos Modelos -->
            <div class="mt-4">
                <h4>Descrição dos Modelos:</h4>
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Modelo 01</h5>
                        <p class="card-text">Este modelo contém apenas a <strong>pergunta simples</strong>.</p>
                    </div>
                </div>

                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Modelo 02</h5>
                        <p class="card-text">Este modelo contém uma pergunta com as alternativas de <strong>Sim</strong>,
                            <strong>Não</strong> e uma pergunta adicional como <strong>Quais</strong>.</p>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Modelo 03</h5>
                        <p class="card-text">Este modelo contém alternativas com sinais <strong>(+)</strong>,
                            <strong>(-)</strong>, e direções como <strong>Esquerda</strong> ou <strong>Direita</strong>.</p>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Atualizar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        console.log("Hi, I'm using the Laravel-AdminLTE package!");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\CliniMaster\CliniMaster_v01\resources\views/Cadastro/ModeloPergunta/edit.blade.php ENDPATH**/ ?>