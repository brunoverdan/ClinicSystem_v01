<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Lista de Perguntas</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <!-- Botão para adicionar nova pergunta -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="mb-0">Perguntas</h2>
        <a href="<?php echo e(route('modelo_perguntas.create')); ?>" class="btn btn-primary">Adicionar Nova Pergunta</a>
    </div>

    <!-- Mensagem de sucesso -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Tabela de perguntas -->
    <div class="card">
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th>Pergunta</th>
                        <th>Modelo</th>
                        <th>Aba</th>
                        <th>Profissional</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $modeloPerguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pergunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pergunta->pergunta); ?></td>
                            <td><?php echo e(ucfirst(str_replace('_', ' ', $pergunta->modelo))); ?></td> <!-- Modelo formatado -->
                            <td><?php echo e($pergunta->aba); ?></td>
                            <td><?php echo e($pergunta->user->name ?? 'N/A'); ?></td> <!-- Nome do usuário relacionado -->
                            <td>
                                <!-- Botões de ações -->
                                <a href="<?php echo e(route('modelo_perguntas.edit', $pergunta->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                                
                                <form action="<?php echo e(route('modelo_perguntas.destroy', $pergunta->id)); ?>" method="POST" style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- CSS personalizado -->
    <style>
        .table-hover tbody tr:hover {
            background-color: #f1f1f1;
        }
        .table-striped > tbody > tr:nth-of-type(odd) {
            background-color: #f9f9f9;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log("Página de lista de perguntas carregada!"); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\CliniMaster\CliniMaster_v01\resources\views/Cadastro/ModeloPergunta/index.blade.php ENDPATH**/ ?>