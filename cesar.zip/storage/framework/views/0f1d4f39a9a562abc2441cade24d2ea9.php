<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-secondary text-white">
            <h1 class="mb-0">Questionario do Cliente</h1>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('fichas.update', ['cliente_id' => $cliente->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> <!-- Adicione este método para indicar uma atualização -->
                
                <h2 class="mb-4">Perguntas</h2>

                <?php $__currentLoopData = $respostas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pergunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <div class="form-group mb-4">
                        <label class="form-label"><?php echo e($pergunta->pergunta); ?></label>
                        
                        <?php
                            // Se houver resposta, usa a primeira resposta. Caso contrário, cria uma resposta vazia.
                            $resposta = $pergunta->respostas->first() ?? new \App\Models\Resposta;
                        ?>
                        
                        <?php if($pergunta->modelo == 'modelo_01'): ?>
                         
                            <div class="mb-2">
                                <textarea type="text" name="perguntas[<?php echo e($pergunta->id); ?>][resposta]" class="form-control" rows="3" placeholder="Especifique se necessário"><?php echo e($resposta->resposta  ?? ''); ?></textarea>
                                <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][tipo_modelo]" value="modelo_01">
                                <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta_id]" value="<?php echo e($pergunta->id); ?>">
                                <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta]" value="<?php echo e($pergunta->pergunta); ?>">
                                <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][aba]" value="<?php echo e($pergunta->aba); ?>">
                            </div>

                        <?php elseif($pergunta->modelo == 'modelo_02'): ?>
                            <div class="mb-2">
                                <label class="form-label d-block">Resposta:</label>
                                <div class="form-check form-check-inline">
                                    <input type="radio" name="perguntas[<?php echo e($pergunta->id); ?>][resposta]" value="sim" class="form-check-input" <?php echo e(($resposta->resposta ?? '') == 'sim' ? 'checked' : ''); ?>>
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][tipo_modelo]" value="modelo_02">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta_id]" value="<?php echo e($pergunta->id); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta]" value="<?php echo e($pergunta->pergunta); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][aba]" value="<?php echo e($pergunta->aba); ?>">
                                    <label class="form-check-label">Sim</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input type="radio" name="perguntas[<?php echo e($pergunta->id); ?>][resposta]" value="nao" class="form-check-input" <?php echo e(($resposta->resposta ?? '') == 'nao' ? 'checked' : ''); ?>>
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][tipo_modelo]" value="modelo_02">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta_id]" value="<?php echo e($pergunta->id); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta]" value="<?php echo e($pergunta->pergunta); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][aba]" value="<?php echo e($pergunta->aba); ?>">
                                    <label class="form-check-label">Não</label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="quais" class="form-label">Quais?</label>
                                <input type="text" name="perguntas[<?php echo e($pergunta->id); ?>][quais]" class="form-control" placeholder="Especifique se necessário" value="<?php echo e($resposta->quais ?? ''); ?>">
                                <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][tipo_modelo]" value="modelo_02">
                                <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta_id]" value="<?php echo e($pergunta->id); ?>">
                                <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta]" value="<?php echo e($pergunta->pergunta); ?>">
                                <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][aba]" value="<?php echo e($pergunta->aba); ?>">
                            </div>

                        <?php elseif($pergunta->modelo == 'modelo_03'): ?>
                            <div class="mt-2">
                                <div class="form-check">
                                    <input type="checkbox" name="perguntas[<?php echo e($pergunta->id); ?>][mais]" value="1" class="form-check-input" <?php echo e(($resposta->mais ?? 0) ? 'checked' : ''); ?>>
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][tipo_modelo]" value="modelo_03">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta_id]" value="<?php echo e($pergunta->id); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta]" value="<?php echo e($pergunta->pergunta); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][aba]" value="<?php echo e($pergunta->aba); ?>">
                                    <label class="form-check-label">Mais</label>
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" name="perguntas[<?php echo e($pergunta->id); ?>][menos]" value="1" class="form-check-input" <?php echo e(($resposta->menos ?? 0) ? 'checked' : ''); ?>>
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][tipo_modelo]" value="modelo_03">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta_id]" value="<?php echo e($pergunta->id); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta]" value="<?php echo e($pergunta->pergunta); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][aba]" value="<?php echo e($pergunta->aba); ?>">
                                    <label class="form-check-label">Menos</label>
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" name="perguntas[<?php echo e($pergunta->id); ?>][direito]" value="1" class="form-check-input" <?php echo e(($resposta->direito ?? 0) ? 'checked' : ''); ?>>
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][tipo_modelo]" value="modelo_03">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta_id]" value="<?php echo e($pergunta->id); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta]" value="<?php echo e($pergunta->pergunta); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][aba]" value="<?php echo e($pergunta->aba); ?>">
                                    <label class="form-check-label">Direito</label>
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" name="perguntas[<?php echo e($pergunta->id); ?>][esquerdo]" value="1" class="form-check-input" <?php echo e(($resposta->esquerdo ?? 0) ? 'checked' : ''); ?>>
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][tipo_modelo]" value="modelo_03">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta_id]" value="<?php echo e($pergunta->id); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][pergunta]" value="<?php echo e($pergunta->pergunta); ?>">
                                    <input type="hidden" name="perguntas[<?php echo e($pergunta->id); ?>][aba]" value="<?php echo e($pergunta->aba); ?>">

                                    <label class="form-check-label">Esquerdo</label>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="text-end">
                    <button type="submit" class="btn btn-success">Salvar Ficha</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\laravel\CliniMaster\CliniMaster_v01\resources\views/Movimentacao/Ficha/edit.blade.php ENDPATH**/ ?>