

<?php $__env->startSection('title', 'Editar Cliente'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Cliente</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('clientes.update', $cliente->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" class="form-control" name="nome" value="<?php echo e($cliente->nome); ?>" required>
                </div>
                <div class="form-group">
                    <label for="telefone">Telefone:</label>
                    <input type="text" class="form-control" name="telefone" value="<?php echo e($cliente->telefone); ?>">
                </div>
                <div class="form-group">
                    <label for="cidade">Cidade:</label>
                    <input type="text" class="form-control" name="cidade" value="<?php echo e($cliente->cidade); ?>">
                </div>
                <div class="form-group">
                    <label for="sexo">Sexo:</label>
                    <select class="form-control" name="sexo" required>
                        <option value="">Selecione</option>
                        <option value="Masculino" <?php echo e($cliente->sexo == 'Masculino' ? 'selected' : ''); ?>>Masculino</option>
                        <option value="Feminino" <?php echo e($cliente->sexo == 'Feminino' ? 'selected' : ''); ?>>Feminino</option>
                        <option value="Nao Escolha" <?php echo e($cliente->sexo == 'Nao Escolha' ? 'selected' : ''); ?>>Não Escolha</option>
                    </select>
                </div>
                
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="endereco">Endereço:</label>
                    <input type="text" class="form-control" name="endereco" value="<?php echo e($cliente->endereco); ?>">
                </div>
                <div class="form-group">
                    <label for="email">E-mail:</label>
                    <input type="email" class="form-control" name="email" value="<?php echo e($cliente->email); ?>">
                </div>
                <div class="form-group">
                    <label for="uf">UF:</label>
                    <input type="text" class="form-control" name="uf" maxlength="2" value="<?php echo e($cliente->uf); ?>">
                </div>
                <div class="form-group">
                    <label for="data_nascimento">Data de Nascimento:</label>
                    <input type="date" class="form-control" name="data_nascimento" value="<?php echo e($cliente->data_nascimento); ?>">
                </div>
                
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label for="observacao">Observacao:</label>
                    <textarea type="text" class="form-control" name="observacao" rows="5"><?php echo e($cliente->observacao); ?></textarea>
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-success">Salvar</button>
        <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-secondary">Voltar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log("Hi, I'm using the Laravel-AdminLTE package!"); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\ClinicSystem\ClinicSystem_v01\resources\views/Cadastro/Cliente/edit.blade.php ENDPATH**/ ?>